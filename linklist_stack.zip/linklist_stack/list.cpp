#include <stdio.h>
#include <stdlib.h>
#include "list.h"
list_datatype *list;
int number_element = 0;
void init_list() {
	list = (list_datatype*)malloc(sizeof(list_datatype));
	list->first = NULL;
	list->last = NULL;
}
void insert_head_node(int x) {
	Node *newnode = (Node*)malloc(sizeof(Node));
	newnode->data = x;
	if(list->first == NULL) {
		list->first = newnode;
		list->last = newnode;
		number_element++;
	} else {
		newnode->next = list->first;
		list->first = newnode;
		number_element++;
	}
}
void insert_last_node(int x) {
	Node *newnode = (Node*)malloc(sizeof(Node));
	Node *temperate = (Node*)malloc(sizeof(Node));
	newnode->data = x;
	if(list->last == NULL) {
		list->last = newnode;
		list->first = newnode;
		number_element++;
	} else {
		temperate = list->last;
		temperate->next = newnode;
		list->last = newnode;
		number_element++;
	}

}

void insert_middle_node(int x, int location) {
	if(number_element < 2 || location < 2 || location >= number_element) {
		printf("ERORR INSERT\n");
		exit(1);
	}
	int count_element = 1;
	Node *newnode = (Node*)malloc(sizeof(Node));
	newnode->data = x;
	Node *temperate = list->first;
	while(count_element != location - 1) {
		temperate = temperate->next;
		count_element++;
	}
	newnode->next = temperate->next;
	temperate->next = newnode;
	number_element++;
}

void delete_head() {
	Node *temperate = list->first;
	list->first = temperate->next;
	number_element--;
	free(temperate);
}
void delete_last() {
	Node *temperate1 = list->first;
	Node *temperate2 = list->first;
	while(temperate1->next != NULL) {
		temperate2 = temperate1;
		temperate1 = temperate1->next;
	}
	temperate2->next = NULL;
	list->last = temperate2;
	number_element--;
	free(temperate1);
}
void delete_middle_node(int location) {
	if(number_element < 2 || location < 2 || location >= number_element) {
		printf("ERORR DELETE\n");
		exit(1);
	}
	int count_element = 1;
	Node *temperate1 = list->first;
	Node *temperate2 ;
	while(count_element != location - 1) {
		temperate1 = temperate1->next;
		count_element++;
	}
	temperate2 = temperate1->next;
	temperate1->next = temperate2->next;
	number_element--;
	free(temperate2);

}
void display_list() {
	Node *tmp = list->first;
	while(tmp) {
		printf("%p %d ",tmp,tmp->data);
		tmp = tmp->next;
	}
	printf("\n");
}

int main() {
	init_list();
	printf("CHEN VAO DAU DANH SACH\n");
	insert_head_node(2);
	insert_head_node(3);
	insert_head_node(4);
	display_list();
	printf("CHEN VAO SAU DANH SACH\n");
	insert_last_node(1);
	insert_last_node(2);
	insert_last_node(3);
	insert_last_node(4);
	insert_last_node(5);
	// printf("%p\n",list->last->next->next->next);
    display_list();
	printf("CHEN VAO GIUA DANH SACH\n");
    insert_middle_node(10,3);
    insert_middle_node(20,6);
    insert_middle_node(50,9);
    display_list();
	printf("XOA DAU DANH SACH\n");
	delete_head();
	delete_head();
	delete_head();
	delete_head();
	delete_head();
	display_list();
	printf("XOA CUOI DANH SACH\n");
	delete_last();
	delete_last();
	display_list();
	printf("XOA GIUA DANH SACH\n");
	delete_middle_node(2);
	delete_middle_node(2);
	display_list();
    free(list);
	return 0;
}
