typedef struct node {
    int data;
    struct node *next;
}Node;
typedef struct list {
	Node *first;
	Node *last;
}list_datatype;
void init_list();
void insert_head_node(int x);
void insert_last_node(int x);
void insert_middle_node(int x, int location);
void delete_head();
void delete_last();
void display_list();